// main.cpp
#include "Lab3.h"

int main() {
    map<char, Matrix> matrices;
    int choice;

    do {
        printMainMenu();
        cin >> choice;
        clearInputBuffer();

        switch (choice) {
            case 1: { // Create new matrix
                char label = getMatrixLabel();

                if (matrices.find(label) != matrices.end()) {
                    cout << "Matrix " << label << " already exists. Overwrite? (y/n): ";
                    char confirm;
                    cin >> confirm;
                    if (tolower(confirm) != 'y') continue;
                }

                int rows, cols;
                cout << "Enter number of rows: ";
                cin >> rows;
                cout << "Enter number of columns: ";
                cin >> cols;

                matrices[label] = Matrix(rows, cols);
                cout << "Enter matrix elements:\n";
                matrices[label].inputMatrix();
                cout << "Matrix " << label << " created successfully.\n";
                break;
            }
            case 2: { // Perform operations
                if (matrices.empty()) {
                    cout << "No matrices available. Please create a matrix first.\n";
                    continue;
                }

                listMatrices(matrices);
                char label = getMatrixLabel();

                if (matrices.find(label) == matrices.end()) {
                    cout << "Matrix " << label << " does not exist.\n";
                    continue;
                }

                int operation;
                do {
                    printOperationMenu();
                    cin >> operation;

                    if (operation == 8) break;
                    if (operation < 1 || operation > 8) {
                        cout << "Invalid option. Please try again.\n";
                        continue;
                    }

                    processMatrixOperation(matrices[label], operation);
                } while (true);
                break;
            }
            case 3: { // List matrices
                listMatrices(matrices);
                break;
            }
            case 4: { // Delete matrix
                if (matrices.empty()) {
                    cout << "No matrices to delete.\n";
                    continue;
                }

                listMatrices(matrices);
                char label = getMatrixLabel();

                if (matrices.find(label) == matrices.end()) {
                    cout << "Matrix " << label << " does not exist.\n";
                    continue;
                }

                matrices.erase(label);
                cout << "Matrix " << label << " deleted successfully.\n";
                break;
            }
            case 5: { // Exit
                cout << "Exiting program.\n";
                break;
            }
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}