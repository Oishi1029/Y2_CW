// Lab3.cpp
#include "Lab3.h"


Matrix::Matrix(int n, int m) : rows(n), cols(m) { // Constructor
    data.resize(n, vector<double>(m, 0.0)); // Initialize the matrix with zeros
}


bool validateMatrixDimensions(int rows, int cols, bool systemSolve) { // Validate matrix dimensions
    if (cols == rows + 1) { // Check if the matrix is applicable for solving system of linear equation
        cout << "The matrix have dimensions n x (n+1), applicable for solving system of linear equation.\n";
        return true;
    }

    if (cols == rows) { // Check if the matrix is a square matrix
        cout << "The matrix is a square matrix, not applicable for solving system of linear equation. \n";
        return true;
    }
    return false;
}

bool askToUpdateMatrix(Matrix& currentMatrix, const Matrix& resultMatrix) { // Ask user to update the current matrix with the result
    char updateChoice;
    cout << "Do you want to update the current matrix with the new result? (y/n): ";
    cin >> updateChoice;
    updateChoice = tolower(updateChoice); // Convert to lowercase for consistency

    if (updateChoice == 'y') {
        currentMatrix = resultMatrix; // Update the current matrix
        cout << "Current matrix updated successfully.\n";
        return true;
    }

    cout << "Current matrix is not updated with the result.\n";
    return false;
}

void Matrix::inputMatrix() { // Input matrix manually
    cout << "Enter the matrix elements row by row:\n";
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            cout << "Enter element [" << i << "][" << j << "]: ";
            cin >> data[i][j]; // Input the matrix element
        }
    }
}

void Matrix::inputMatrix(char* argv[], int startIdx) { // Input matrix from program arguments
    int idx = startIdx; // Start index for reading program arguments
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            data[i][j] = stod(argv[idx++]); // Convert program argument to double and assign to matrix
        }
    }
}

void Matrix::display() { // Display the matrix
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            // Display the matrix element with 2 decimal points
            cout << fixed << setprecision(2) << setw(8) << data[i][j] << " ";
        }
        cout << endl;
    }
}

Matrix Matrix::rowEchelon() { // Find the row echelon form of the matrix
    int n = rows;
    int m = cols;
    vector<vector<double>> augmented = data; // Copy the matrix data

    // Perform Gaussian elimination
    for (int i = 0; i < n; i++) { // Loop through the rows
        // Find pivot
        int maxRow = i; // Initialize the maximum row
        for (int k = i + 1; k < n; k++) { // Loop through the rows
            if (abs(augmented[k][i]) > abs(augmented[maxRow][i])) { // Check if the current element is greater than the maximum element
                maxRow = k; // Update the maximum row
            }
        }

        // Swap maximum row with current row
        if (maxRow != i) { // Check if the maximum row is not the current row
            swap(augmented[i], augmented[maxRow]); // Swap the rows
        }

        // Check if the pivot is zero
        if (abs(augmented[i][i]) < 1e-10) {
            continue; // Skip this row if it's effectively zero
        }

        // Scale the pivot row to make the pivot equal to 1
        double pivot = augmented[i][i]; // Get the pivot element
        for (int j = i; j < m; j++) { // Loop through the columns
            augmented[i][j] /= pivot; // Normalize the pivot row
        }

        // Make all rows below this one 0 in current column
        for (int k = i + 1; k < n; k++) { // Loop through the rows below the pivot row
            double factor = augmented[k][i]; // Get the factor to make the element zero
            for (int j = i; j < m; j++) { // Loop through the columns
                augmented[k][j] -= factor * augmented[i][j]; // Make the element zero
            }
        }
    }

    Matrix ref(n, m); // Create a new matrix for the row echelon form
    ref.data = augmented; // Directly assign the modified data
    return ref;
}
Matrix Matrix::reducedRowEchelon() { // Find the reduced row echelon form of the matrix
    Matrix ref = rowEchelon(); // Get REF
    int n = ref.rows;
    int m = ref.cols;
    vector<vector<double>> augmented = ref.data; // Copy the matrix data

    // Convert REF to RREF
    for (int i = n - 1; i >= 0; i--) { // Loop through the rows in reverse order
        double pivot = augmented[i][i]; // Get the pivot element
        for (int j = 0; j < m; j++) { // Loop through the columns
            augmented[i][j] /= pivot; // Normalize the pivot row
        }
        for (int k = i - 1; k >= 0; k--) { // Loop through the rows above the pivot row
            double factor = augmented[k][i]; // Get the factor to make the element zero
            for (int j = 0; j < m; j++) { // Loop through the columns
                augmented[k][j] -= factor * augmented[i][j]; // Make the element zero
            }
        }
    }


    Matrix rref(n, m); // Create a new matrix for the reduced row echelon form
    for (int i = 0; i < n; i++) { // Loop through the rows
        for (int j = 0; j < m; j++) { // Loop through the columns
            rref.data[i][j] = augmented[i][j]; // Assign the element to the new matrix
        }
    }

    return rref;
}
vector<double> Matrix::solveLinearSystem() { // Solve the system of linear equations
    if (cols != rows + 1) { // Check if the matrix is applicable for solving system of linear equation
        throw runtime_error("Matrix must have n rows and n+1 columns for system solving");
    }

    // Get the reduced row echelon form
    Matrix rref = reducedRowEchelon();

    // Determine the rank of the coefficient matrix and the augmented matrix
    int rank = 0;
    int augmentedRank = 0;

    // Check for consistency and determine ranks
    for (int i = 0; i < rows; i++) { // Loop through the rows
        bool isZeroRow = true; // Initialize the row as zero
        bool isAugmentedZeroRow = true; // Initialize the augmented row as zero

        for (int j = 0; j < cols; j++) { // Loop through the columns
            if (abs(rref.data[i][j]) > 1e-10) { // Check for non-zero in the row
                isZeroRow = false; // Update the row as non-zero
            }
            if (j < cols - 1 && abs(rref.data[i][j]) > 1e-10) { // Check for non-zero in coefficient part
                isAugmentedZeroRow = false; // Update the augmented row as non-zero
            }
        }

        if (!isZeroRow) { // Check for non-zero in the row
            rank++; // Update the rank
        }
        if (!isAugmentedZeroRow && abs(rref.data[i][cols - 1]) > 1e-10) { // Check for non-zero in the last column
            augmentedRank++; // Update the augmented rank
        }
    }

    // Determine the type of solution
    if (rank < augmentedRank) { // Check for inconsistent system
        cout << "No Solution\n";
        return {}; // No solution
    } else if (rank < rows) { // Check for infinite solutions
        cout << "Infinite Solutions\n";
        return {}; // Infinite solutions
    }


    vector<double> solution(rows); // Initialize the solution vector
    for (int i = rows - 1; i >= 0; i--) { // Loop through the rows in reverse order
        solution[i] = rref.data[i][cols - 1]; // The last column is the solution
        for (int j = i + 1; j < cols - 1; j++) { // Exclude the last column
            solution[i] -= rref.data[i][j] * solution[j]; // Subtract the known values
        }
    }

    return solution;
}

bool Matrix::isSquare() { // Check if the matrix is square
    return rows == cols; // Check if the number of rows is equal to the number of columns
}

Matrix Matrix::augmentIdentity() { // Augment the matrix with an identity matrix
    if (!isSquare()) { // Check if the matrix is square
        throw runtime_error("Matrix must be square for inversion"); // Throw an error if the matrix is not square
    }

    Matrix augmented(rows, 2 * cols); // Create a new matrix with double the columns

    // Copy original matrix
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            augmented.data[i][j] = data[i][j]; // Copy the original matrix
        }
    }

    // Add identity matrix
    for (int i = 0; i < rows; i++) { // Loop through the rows
        augmented.data[i][i + cols] = 1.0; // Add the identity matrix
    }

    return augmented;
}

Matrix Matrix::inverse() { // Find the inverse of the matrix
    if (!isSquare()) { // Check if the matrix is square
        throw runtime_error("Matrix must be square for inversion");
    }

    Matrix augmented = augmentIdentity(); // Augment the matrix with an identity matrix

    // Gaussian elimination
    for (int i = 0; i < rows; i++) { // Loop through the rows
        // Find pivot
        int maxRow = i;
        for (int k = i + 1; k < rows; k++) { // Loop through the rows
            if (abs(augmented.data[k][i]) > abs(augmented.data[maxRow][i])) { // Check if the current element is greater than the maximum element
                maxRow = k; // Update the maximum row
            }
        }

        if (abs(augmented.data[maxRow][i]) < 1e-10) { // Check if the pivot is zero
            throw runtime_error("Matrix is singular, cannot find inverse"); // Throw an error if the matrix is singular
        }

        // Swap maximum row with current row
        if (maxRow != i) { // Check if the maximum row is not the current row
            swap(augmented.data[i], augmented.data[maxRow]); // Swap the rows
        }

        // Scale current row
        double scale = augmented.data[i][i];
        for (int j = i; j < 2 * cols; j++) { // Loop through the columns
            augmented.data[i][j] /= scale; // Scale the current row
        }

        // Eliminate column
        for (int k = 0; k < rows; k++) { // Loop through the rows
            if (k != i) { // Skip the current row
                double factor = augmented.data[k][i]; // Get the factor to make the element zero
                for (int j = i; j < 2 * cols; j++) { // Loop through the columns
                    augmented.data[k][j] -= factor * augmented.data[i][j]; // Make the element zero
                }
            }
        }
    }

    // Extract inverse matrix
    Matrix inverse(rows, cols);
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            inverse.data[i][j] = augmented.data[i][j + cols]; // Extract the inverse matrix
        }
    }

    return inverse;
}

// Add this method to Lab3.cpp
void Matrix::inputValue(int i, int j, double value) { // Set a specific element in the matrix
    if (i >= 0 && i < rows && j >= 0 && j < cols) { // Check if the indices are valid
        data[i][j] = value; // Set the element value
    }
}

void Matrix::print() { // Print the matrix
    int maxWidth = 0; // Initialize the maximum width

    // Find the maximum width needed
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            ostringstream ss; // Create a string stream
            ss << fixed << setprecision(6) << data[i][j]; // Set the precision and convert the element to string
            maxWidth = max(maxWidth, static_cast<int>(ss.str().length())); // Update the maximum width
        }
    }

    // Print the matrix with aligned columns
    cout << "\n";
    for (int i = 0; i < rows; i++) { // Loop through the rows
        cout << "|";
        for (int j = 0; j < cols; j++) { // Loop through the columns
            cout << setw(maxWidth + 2) << fixed << setprecision(6) << data[i][j]; // Print the element with 2 decimal points
        }
        cout << " |\n";
    }
    cout << "\n";
}

bool Matrix::isValidIndex(int m, int n) const { // Check if the indices are valid
    return m >= 0 && m < rows && n >= 0 && n < cols; // Check if the indices are within the matrix dimensions
}

void Matrix::set(int m, int n, double x) { // Set a specific element in the matrix
    if (!isValidIndex(m, n)) { // Check if the indices are valid
        throw out_of_range("Matrix indices out of range"); // Throw an error if the indices are out of range
    }
    data[m][n] = x; // Set the element value
}

double Matrix::get(int m, int n) { // Get a specific element in the matrix
    if (!isValidIndex(m, n)) { // Check if the indices are valid
        throw out_of_range("Matrix indices out of range"); // Throw an error if the indices are out of range
    }
    return data[m][n]; // Return the element value
}

void Matrix::save(string filename) {
    // Check if filename has an extension
    size_t dotPos = filename.find_last_of('.'); // Find the last occurrence of the dot
    string extension = (dotPos != string::npos) ? filename.substr(dotPos) : ""; // Get the extension

    // If no extension, ask the user for one
    if (extension.empty()) { // Check if the extension is empty
        char choice;
        cout << "No file extension provided. Choose an extension:\n";
        cout << "1. .mat\n";
        cout << "2. .txt\n";
        cout << "Enter your choice (1/2): ";
        cin >> choice; // Get the user choice

        if (choice == '1') {
            filename += ".mat"; // Add the .mat extension
        } else {
            filename += ".txt"; // Add the .txt extension
        }
    }

    cout << "Matrix saved successfully to " << filename << endl;

    ofstream outFile(filename); // Open the file for writing
    if (!outFile) { // Check if the file is opened successfully
        throw runtime_error("Unable to open file for writing: " + filename); // Throw an error if the file is not opened
    }

    // Write in MATLAB/Octave ASCII format
    outFile << scientific << setprecision(16);

    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            outFile << data[i][j]; // Write the element to the file
            if (j < cols - 1) outFile << " "; // Space between elements
        }
        outFile << "\n"; // New line after each row
    }

    outFile.close();
    if (!outFile) { // Check if the file is closed successfully
        throw runtime_error("Error occurred while writing to file: " + filename);
    }
}
void Matrix::load(string filename) { // Load matrix from file
    // Check if filename has an extension
    size_t dotPos = filename.find_last_of('.'); // Find the last occurrence of the dot
    string extension = (dotPos != string::npos) ? filename.substr(dotPos) : ""; // Get the extension

    // If no extension, ask the user for one
    if (extension.empty()) { // Check if the extension is empty
        char choice;
        cout << "No file extension provided. Choose an extension:\n";
        cout << "1. .mat\n";
        cout << "2. .txt\n";
        cout << "Enter your choice (1/2): ";
        cin >> choice;

        if (choice == '1') {
            filename += ".mat"; // Add the .mat extension
        } else if (choice == '2') {
            filename += ".txt"; // Add the .txt extension
        } else {
            throw runtime_error("Invalid choice for file extension."); // Throw an error if the choice is invalid
        }
    }

    ifstream inFile(filename); // Open the file for reading
    if (!inFile) { // Check if the file is opened successfully
        throw runtime_error("Unable to open file: " + filename); // Throw an error if the file is not opened
    }

    vector<vector<double>> tempData; // Temporary data storage
    string line; // Initialize the line
    int numCols = -1;

    while (getline(inFile, line)) { // Read the file line by line
        // Skip empty lines
        if (line.empty()) continue;

        vector<double> row; // Initialize the row
        stringstream ss(line); // Create a string stream
        double value;

        while (ss >> value) { // Read the line element by element
            row.push_back(value); // Add the element to the row
        }

        // Verify consistency of number of columns
        if (numCols == -1) { // Check if the number of columns is not set
            numCols = row.size(); // Update the number of columns
        } else if (numCols != static_cast<int>(row.size())) { // Check if the number of columns is consistent
            throw runtime_error("Inconsistent number of columns in file: " + filename); // Throw an error if the number of columns is inconsistent
        }

        tempData.push_back(row); // Add the row to the temporary data
    }

    if (tempData.empty()) { // Check if the data is empty
        throw runtime_error("No data found in file: " + filename); // Throw an error if the data is empty
    }

    // Update matrix dimensions and data
    rows = tempData.size(); // Update the number of rows
    cols = tempData[0].size(); // Update the number of columns
    data = tempData; // Update the matrix data
}


Matrix Matrix::identity(int n) { // Create an identity matrix
    Matrix identity(n, n); // Initialize the identity matrix
    for (int i = 0; i < n; i++) { // Loop through the rows
        identity.data[i][i] = 1.0; // Set the diagonal elements to 1
    }
    return identity;
}

Matrix Matrix::zero(int n, int m) { // Create a zero matrix
    return Matrix(n, m); // Return a matrix with all elements as zero
}

Matrix Matrix::transpose() const { // Transpose the matrix
    Matrix result(cols, rows); // Create a new matrix with transposed dimensions
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            result.data[j][i] = data[i][j]; // Transpose the element
        }
    }
    return result;
}




Matrix Matrix::operator+(const Matrix& other) const { // Add two matrices
    if (rows != other.rows || cols != other.cols) { // Check if the dimensions are the same
        throw runtime_error("Dimension mismatch for addition."); // Throw an error if the dimensions are different
    }
    Matrix result(rows, cols); // Create a new matrix for the result
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            result.data[i][j] = data[i][j] + other.data[i][j]; // Add the elements
        }
    }
    return result;
}

Matrix Matrix::operator-(const Matrix& other) const { // Subtract two matrices
    if (rows != other.rows || cols != other.cols) { // Check if the dimensions are the same
        throw runtime_error("Dimension mismatch for subtraction."); // Throw an error if the dimensions are different
    }
    Matrix result(rows, cols); // Create a new matrix for the result
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            result.data[i][j] = data[i][j] - other.data[i][j]; // Subtract the elements
        }
    }
    return result;
}

Matrix Matrix::operator*(const Matrix& other) const { // Multiply two matrices
    if (cols != other.rows) { // Check if the dimensions are valid for multiplication
        throw runtime_error("Dimension mismatch for multiplication."); // Throw an error if the dimensions are invalid
    }
    Matrix result(rows, other.cols); // Create a new matrix for the result
    for (int i = 0; i < rows; i++) {  // Loop through the rows
        for (int j = 0; j < other.cols; j++) { // Loop through the columns
            for (int k = 0; k < cols; k++) { // Loop through the columns of the other matrix
                result.data[i][j] += data[i][k] * other.data[k][j];
            }
        }
    }
    return result;
}

Matrix Matrix::operator*(double scalar) const { // Multiply matrix by scalar
    Matrix result(rows, cols); // Create a new matrix for the result
    for (int i = 0; i < rows; i++) { // Loop through the rows
        for (int j = 0; j < cols; j++) { // Loop through the columns
            result.data[i][j] = data[i][j] * scalar; // Multiply the element by scalar
        }
    }
    return result;
}

string Matrix::solutionType() { // Determine the type of solution for the system of linear equations
    if (cols != rows + 1) { // Check if the matrix is applicable for solving system of linear equation
        throw runtime_error("Matrix must have dimensions n x (n+1) for solution analysis.");
    }

    vector<vector<double>> augmented = data; // Copy for row reduction
    int n = rows;

    // Row reduction to echelon form
    for (int i = 0; i < n; i++) { // Loop through the rows
        // Find pivot
        int maxRow = i; // Initialize the maximum row
        for (int k = i + 1; k < n; k++) { // Loop through the rows
            if (abs(augmented[k][i]) > abs(augmented[maxRow][i])) { // Check if the current element is greater than the maximum element
                maxRow = k;
            }
        }

        // Swap rows if necessary
        if (maxRow != i) { // Check if the maximum row is not the current row
            swap(augmented[i], augmented[maxRow]); // Swap the rows
        }

        // If pivot is zero, the system might be degenerate
        if (abs(augmented[i][i]) < 1e-10) { // Check if the pivot is zero
            continue;
        }

        // Eliminate below
        for (int k = i + 1; k < n; k++) { // Loop through the rows below the pivot row
            double factor = augmented[k][i] / augmented[i][i]; // Get the factor to make the element zero
            for (int j = i; j <= n; j++) { // Loop through the columns
                augmented[k][j] -= factor * augmented[i][j]; // Make the element zero
            }
        }
    }

    // Analyze the reduced matrix
    int rank = 0;
    for (int i = 0; i < n; i++) { // Loop through the rows
        bool nonZeroRow = false; // Initialize the row as zero
        for (int j = 0; j < cols; j++) { // Loop through the columns
            if (abs(augmented[i][j]) > 1e-10) { // Check for non-zero in the row
                nonZeroRow = true; // Update the row as non-zero
                break;
            }
        }
        if (nonZeroRow) rank++; // Update the rank
    }

    if (rank < n) {
        // Check for inconsistency (e.g., 0 = 1)
        for (int i = rank; i < n; i++) { // Loop through the rows
            if (abs(augmented[i][n]) > 1e-10) { // Check for non-zero in the last column
                return "No Solution";
            }
        }
        return "Infinite Solutions";
    }

    return "Unique Solution";
}

double Matrix::determinant() const { // Calculate the determinant of the matrix
    if (rows != cols) { // Check if the matrix is square
        throw runtime_error("Determinant can only be calculated for square matrices.");
    }

    vector<vector<double>> temp = data; // Copy the matrix to perform operations
    double det = 1.0;

    for (int i = 0; i < rows; i++) { // Loop through the rows
        // Find pivot
        int pivotRow = i;
        for (int j = i + 1; j < rows; j++) { // Loop through the rows
            if (abs(temp[j][i]) > abs(temp[pivotRow][i])) { // Check if the current element is greater than the maximum element
                pivotRow = j; // Update the pivot row
            }
        }

        if (abs(temp[pivotRow][i]) < 1e-10) { // Check if the pivot is zero
            return 0.0; // Singular matrix
        }

        // Swap rows if necessary
        if (pivotRow != i) { // Check if the pivot row is not the current row
            swap(temp[i], temp[pivotRow]); // Swap the rows
            det *= -1; // Row swap changes the sign of the determinant
        }

        // Scale determinant by pivot
        det *= temp[i][i];

        // Eliminate below
        for (int j = i + 1; j < rows; j++) { // Loop through the rows below the pivot row
            double factor = temp[j][i] / temp[i][i]; // Get the factor to make the element zero
            for (int k = i; k < cols; k++) { // Loop through the columns
                temp[j][k] -= factor * temp[i][k]; // Make the element zero
            }
        }
    }

    return det;
}


void clearInputBuffer() { // Clear the input buffer
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore the remaining characters in the buffer
}

void printMainMenu() {
    cout << "\nMain Menu:\n";
    cout << "1. Create new matrix\n";
    cout << "2. Select matrix to perform operations\n";
    cout << "3. List all matrices\n";
    cout << "4. Delete matrix\n";
    cout << "5. Exit\n";
    cout << "Enter choice (1-5): ";
}
void printOperationMenu() {
    const int width = 50; // Set a uniform width for each menu item

    //cout << "\nEssential Matrix Operations Menu:                Mathematical Operations Menu:\n";

    cout << left << setw(width) << "Essential Matrix Operations Menu"
         << left << setw(width) << "Mathematical Operations Menu:" << endl;
    cout << left << setw(width) << "1. Find row echelon form (REF)"
         << left << setw(width) << "11. Transpose" << endl;
    cout << left << setw(width) << "2. Find reduced row echelon form (RREF)"
         << left << setw(width) << "12. Identity Matrix" << endl;
    cout << left << setw(width) << "3. Solve system of linear equations"
         << left << setw(width) << "13. Zero Matrix" << endl;
    cout << left << setw(width) << "4. Find inverse matrix (Gaussian method)"
         << left << setw(width) << "14. Add Matrices" << endl;
    cout << left << setw(width) << "5. Print matrix"
         << left << setw(width) << "15. Subtract Matrices" << endl;
    cout << left << setw(width) << "6. Set specific element"
         << left << setw(width) << "16. Left Multiply Matrices" << endl;
    cout << left << setw(width) << "7. Get specific element"
         << left << setw(width) << "17. Right Multiply Matrices" << endl;
    cout << left << setw(width) << "8. Save matrix to file"
         << left << setw(width) << "18. Scalar Multiply" << endl;
    cout << left << setw(width) << "9. Load matrix from file"
         << left << setw(width) << "19. Inverse (Normal method)" << endl;
    cout << left << setw(width) << "10. Return to main menu"
         << left << setw(width) << "20. Determinant" << endl;
    cout << "\nEnter choice (1-20): ";
}

bool validateDimensions(int rows, int cols, int operation) { // Validate the matrix dimensions for the operation

    // Check if the matrix is applicable for the operation
    if (operation == 1 && cols != rows + 1) {
        cout << "For system solving, columns must be rows + 1\n";
        return false; // Return false if the matrix is not applicable
    }

    // Check if the matrix is applicable for the operation
    if (operation == 2 && cols != rows) {
        cout << "For inverse, matrix must be square\n";
        return false; // Return false if the matrix is not applicable
    }
    return true; // Return true if the matrix is applicable
}

void listMatrices(const map<char, Matrix>& matrices) { // List all the matrices
    cout << "\nExisting matrices label (e.g. A, B, C, D):\n";
    if (matrices.empty()) { // Check if the map is empty
        cout << "No matrices created yet.\n";
        return; // Return if the map is empty
    }
    for (const auto& pair : matrices) { // Loop through the map

        // Print the matrix label and dimensions
        cout << "Matrix " << pair.first << " ("
             << pair.second.getRows() << "x"
             << pair.second.getCols() << ")\n";
    }
}

char getMatrixLabel() { // Get the matrix label
    char label; // Initialize the label
    do {
        cout << "Enter matrix label (A-Z): ";
        cin >> label;
        label = toupper(label); // Convert the label to uppercase
        clearInputBuffer(); // Clear the input buffer

        if (label < 'A' || label > 'Z') { // Check if the label is valid
            cout << "Invalid label. Please use letters A-Z.\n";
            continue; // Continue the loop if the label is invalid
        }
        break; // Break the loop if the label is valid
    } while (true); // Repeat the loop until a valid label is entered
    return label;
}




void processMatrixOperation(Matrix& mat, int operation, map<char, Matrix>& matrices) { // Process the matrix operation
    try {
        Matrix result; // Initialize the result matrix
        switch (operation) { // Switch based on the operation

            case 1: // Row Echelon

                if (!validateDimensions(mat.getRows(), mat.getCols(), 1)) return; // Validate the matrix dimensions
                result = mat.rowEchelon(); // Get the row echelon form
                result.print(); // Print the row echelon form
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            case 2: // Reduced Row Echelon
                if (!validateDimensions(mat.getRows(), mat.getCols(), 1)) return; // Validate the matrix dimensions
                result = mat.reducedRowEchelon(); // Get the reduced row echelon form
                result.print(); // Print the reduced row echelon form
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;


            case 3: { // Solve system
                if (!validateDimensions(mat.getRows(), mat.getCols(), 1)) return; // Validate the matrix dimensions
                cout << "\nSolution Type: " << mat.solutionType() << endl;// Print the solution type

                if (mat.solutionType() == "Unique Solution") { // Check if the solution is unique
                    vector<double> solution = mat.solveLinearSystem(); // Solve the system of linear equations
                    cout << "\nSolution:\n";
                    for (size_t i = 0; i < solution.size(); i++) { // Loop through the solution
                        cout << "x" << i + 1 << " = " << solution[i] << endl; // Print the solution
                    }
                }
                break;
            }
            case 4: { // Inverse
                if (!validateDimensions(mat.getRows(), mat.getCols(), 2)) return; // Validate the matrix dimensions
                result = mat.inverse(); // Get the inverse matrix
                result.print(); // Print the inverse matrix
                askToUpdateMatrix(mat, result);// Ask the user to update the matrix
                break;
            }
            case 5: { // Print
                mat.print();
                return;
            }
            case 6: { // Set element
                int m, n; // Initialize the row and column indices
                double value; // Initialize the value
                cout << "Enter row index: ";
                cin >> m;
                cout << "Enter column index: ";
                cin >> n;
                cout << "Enter value: ";
                cin >> value;
                mat.set(m, n, value); // Set the element
                cout << "Element updated successfully.\n";
                return;
            }
            case 7: { // Get element
                int m, n;
                cout << "Enter row index: ";
                cin >> m;
                cout << "Enter column index: ";
                cin >> n;
                double value = mat.get(m, n); // Get the element
                cout << "Value at (" << m << "," << n << ") = " << value << endl; // Print the element
                return;
            }
            case 8: { // Save
                string filename; // Initialize the filename
                cout << "Enter filename to save: ";
                clearInputBuffer(); // Clear the input buffer
                getline(cin, filename); // Get the filename
                mat.save(filename); // Save the matrix to the file

                return;
            }
            case 9: { // Load
                string filename; // Initialize the filename
                cout << "Enter filename to load: ";
                clearInputBuffer(); // Clear the input buffer
                getline(cin, filename); // Get the filename
                mat.load(filename); // Load the matrix from the file
                cout << "Matrix loaded successfully from " << filename << endl;
                mat.print();
                return;
            }
            case 11: { // Transpose
                result = mat.transpose(); // Get the transposed matrix
                result.print(); // Print the transposed matrix
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 12: { // Identity
                int size;
                cout << "Enter size of the identity matrix: ";
                cin >> size;
                result = Matrix::identity(size); // Create an identity matrix
                result.print(); // Print the identity matrix
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 13: { // Zero
                int rows, cols;
                cout << "Enter number of rows: ";
                cin >> rows;
                cout << "Enter number of columns: ";
                cin >> cols;
                result = Matrix::zero(rows, cols); // Create a zero matrix
                result.print(); // Print the zero matrix
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 14: { // Add
                char label;
                listMatrices(matrices); // List all the matrices
                cout << "Enter the label of the matrix to add: ";
                cin >> label; // Get the matrix label
                label = toupper(label); // Convert the label to uppercase
                if (matrices.find(label) == matrices.end()) { // Check if the matrix is found
                    throw runtime_error("Matrix not found.");
                }
                result = mat + matrices[label]; // Add the matrices
                result.print(); // Print the result
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 15: { // Subtract
                char label;
                listMatrices(matrices); // List all the matrices
                cout << "Enter the label of the matrix to subtract: ";
                cin >> label;
                label = toupper(label); // Convert the label to uppercase
                if (matrices.find(label) == matrices.end()) { // Check if the matrix is found
                    throw runtime_error("Matrix not found.");
                }
                result = mat - matrices[label]; // Subtract the matrices
                result.print(); // Print the result
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 16: { // Left Multiply
                char label;
                listMatrices(matrices); // List all the matrices
                cout << "Enter the label of the matrix for left multiplication: ";
                cin >> label;
                label = toupper(label); // Convert the label to uppercase
                if (matrices.find(label) == matrices.end()) { // Check if the matrix is found
                    throw runtime_error("Matrix not found."); // Throw an error if the matrix is not found
                }
                result = matrices[label] * mat; // Multiply the matrices
                result.print();
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 17: { // Right Multiply
                char label;
                listMatrices(matrices); // List all the matrices
                cout << "Enter the label of the matrix for right multiplication: ";
                cin >> label;
                label = toupper(label); // Convert the label to uppercase
                if (matrices.find(label) == matrices.end()) { // Check if the matrix is found
                    throw runtime_error("Matrix not found."); // Throw an error if the matrix is not found
                }
                result = mat * matrices[label]; // Multiply the matrices
                result.print();
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 18: { // Scalar Multiply
                double scalar;
                cout << "Enter the scalar value: ";
                cin >> scalar;
                result = mat * scalar; // Multiply the matrix by scalar
                result.print(); // Print the result
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 19: { // Inverse
                result = mat.inverse(); // Get the inverse matrix
                result.print();
                askToUpdateMatrix(mat, result); // Ask the user to update the matrix
                break;
            }
            case 20: { // Determinant
                if (mat.getRows() != mat.getCols()) { // Check if the matrix is square
                    cout << "Determinant can only be calculated for square matrices.\n";
                    break; // Break the loop if the matrix is not square
                }
                double det = mat.determinant(); // Calculate the determinant
                cout << "Determinant: " << det << endl; // Print the determinant
                break;
            }

        }

    } catch (const exception& e) { // Catch any exceptions
        cout << "Error: " << e.what() << endl; // Print the error message
    }
}
