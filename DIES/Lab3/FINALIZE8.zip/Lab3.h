// Lab3.h

#include <vector>
#include <string>
#include <sstream>  // for ostringstream and stringstream
#include <fstream>  // for ofstream and ifstream
#include <iostream>
#include <map>
#include <cctype>
#include <limits>
#include <iomanip>
#include <cmath>
#include <stdexcept>
using namespace std;

class Matrix {
private:
    vector<vector<double> > data; // 2D vector to store matrix elements
    int rows; // Number of rows
    int cols; // Number of columns

public:
    Matrix() : rows(0), cols(0) {} // Default constructor
    Matrix(int n, int m); // Constructor with dimensions


    Matrix transpose() const; // Transpose matrix
    double determinant() const; // Calculate determinant
    static Matrix identity(int n); // Create identity matrix
    static Matrix zero(int rows, int cols); // Create zero matrix
    Matrix operator+(const Matrix& other) const; // Matrix addition
    Matrix operator-(const Matrix& other) const;
    Matrix operator*(const Matrix& other) const; // Matrix multiplication
    Matrix operator*(double scalar) const;      // Scalar multiplication

    Matrix rowEchelon(); // Convert to row echelon form
    Matrix reducedRowEchelon(); // Convert to reduced row echelon form
    string solutionType(); // Determine solution type
    vector<double> solveLinearSystem(); // Solve linear system

    void inputMatrix(); // Input matrix from user
    void inputMatrix(char* argv[], int startIdx); // Input matrix from command line
    void inputValue(int i, int j, double value); // Set matrix element
    Matrix inverse(); // Calculate inverse
    void print(); // Print matrix
    void set(int m, int n, double x); // Set matrix element
    double get(int m, int n); // Get matrix element
    void save(string filename); // Save matrix to file
    void load(string filename); // Load matrix from file
    bool isEmpty() const { return rows == 0 || cols == 0; } // Check if matrix is empty
    int getRows() const { return rows; } // Get number of rows
    int getCols() const { return cols; } // Get number of columns
    void resize(int n, int m); // Resize matrix
    void display(); // Display matrix
    bool askToUpdateMatrix(Matrix& currentMatrix, const Matrix& resultMatrix); // Ask user to update matrix

private:

    void swapRows(int i, int j); // Swap two rows
    Matrix augmentIdentity();  // Augment matrix with identity matrix
    bool isSquare(); // Check if matrix is square
    bool isValidIndex(int m, int n) const;  // Check if index is valid
};

void clearInputBuffer(); // Clear input buffer
void printMainMenu(); // Print main menu
void printOperationMenu(); // Print operation menu
bool validateDimensions(int rows, int cols, int operation); // Validate matrix dimensions
void listMatrices(const map<char, Matrix>& matrices); // List available matrices
char getMatrixLabel(); // Get matrix label
void processMatrixOperation(Matrix& mat, int operation, map<char, Matrix>& matrices); // Process matrix operation
bool validateMatrixDimensions(int rows, int cols, bool systemSolve); // Validate matrix dimensions for system solving or inverse
