#include "Lab3.h"
Matrix getMatrixFromArgsOrInput(int argc, char* argv[], bool systemSolve) {
    int rows, cols;

    // Prompt user for matrix dimensions
    while (true) {
        cout << "Enter the number of rows: ";
        cin >> rows;
        cout << "Enter the number of columns: ";
        cin >> cols;

        // Validate matrix dimensions
        if (validateMatrixDimensions(rows, cols, systemSolve)) {

            break;
        }
    }

    Matrix mat(rows, cols);

    if (argc > 1) {
        // Validate program argument size
        int totalElements = argc - 1; // Remaining arguments are matrix data

        // Check if the number of elements in program arguments matches the specified matrix dimensions
        if (totalElements != rows * cols) {
            throw runtime_error("The number of elements in program arguments does not match the specified matrix dimensions.");
        }

        // Fill matrix from program arguments
        mat.inputMatrix(argv, 1); // Start reading data from argv[1]
        return mat;
    } else {
        // Input matrix manually
        mat.inputMatrix();
        return mat;
    }
}

int main(int argc, char* argv[]) {
    map<char, Matrix> matrices;
    int choice;
    bool systemSolve = true; // Assume the matrix is for solving linear equations

    try {
        cout << "-----Enter matrix dimensions (rows x cols)-----\n";
        Matrix mat = getMatrixFromArgsOrInput(argc, argv, systemSolve); // Create matrix from program arguments or user input
        cout << "Matrix successfully created:\n";
        mat.display(); // Display the matrix
        matrices['A'] = mat; // Store the matrix in the map
    } catch (const exception& e) { // Catch any exceptions thrown
        cerr << "Error: " << e.what() << "\n"; // Print error message
        return 1;
    }

    do {
        printMainMenu(); // Display the main menu
        cin >> choice;
        clearInputBuffer(); // Clear the input buffer

        switch (choice) {
            case 1: { // Create new matrix
                char label = getMatrixLabel();
                bool newSystemSolve = false; // Allow user to specify non-system matrices
                cout << "Is this matrix for solving a system of equations? (y/n): ";
                char resp; // User response
                cin >> resp;
                if (tolower(resp) == 'y') { // If the user's response is 'y'
                    newSystemSolve = true;
                }

                // Create a new matrix
                Matrix newMat = getMatrixFromArgsOrInput(0, nullptr, newSystemSolve);

                // Store the new matrix in the map
                matrices[label] = newMat;
                cout << "Matrix " << label << " created successfully.\n";
                break;
            }
            case 2: { // Perform operations
                if (matrices.empty()) { // If there are no matrices available
                    cout << "No matrices available. Please create a matrix first.\n";
                    continue;
                }

                listMatrices(matrices); // List the available matrices
                char label = getMatrixLabel(); // Get the label of the matrix to perform operations on

                if (matrices.find(label) == matrices.end()) { // If the matrix does not exist
                    cout << "Matrix " << label << " does not exist.\n";
                    continue;
                }

                int operation;
                do {
                    cout<<"Current Matrix: Matrix " << label<<endl;
                    printOperationMenu(); // Display the operation menu
                    cin >> operation;

                    if (operation == 10) break; // If the user chooses to exit the operation menu
                    if (operation < 1 || operation > 20) { // If the operation is invalid
                        cout << "Invalid option. Please try again.\n";
                        continue;
                    }

                    processMatrixOperation(matrices[label], operation, matrices); // Process the matrix operation
                } while (true);
                break;
            }
            case 3: { // List matrices
                listMatrices(matrices); // List the available matrices
                break;
            }
            case 4: { // Delete matrix
                if (matrices.empty()) { // If there are no matrices to delete
                    cout << "No matrices to delete.\n";
                    continue;
                }

                listMatrices(matrices); // List the available matrices
                char label = getMatrixLabel();

                if (matrices.find(label) == matrices.end()) { // If the matrix does not exist
                    cout << "Matrix " << label << " does not exist.\n";
                    continue;
                }

                matrices.erase(label); // Delete the matrix
                cout << "Matrix " << label << " deleted successfully.\n";
                break;
            }
            case 5: { // Exit
                cout << "Exiting program.\n";
                break;
            }
            default: // If the choice is invalid
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
