#include "Lab3.h"
bool validateMatrixDimensions(int rows, int cols, bool systemSolve) {
    if (cols == rows + 1) {
        cout << "The matrix have dimensions n x (n+1), applicable for solving system of linear equation.\n";
        return true;
    }

    if (cols == rows) {
        cout << "The matrix is a square matrix, not applicable for solving system of linear equation. \n";
        return true;
    }
    return false;
}

Matrix getMatrixFromArgsOrInput(int argc, char* argv[], bool systemSolve) {
    int rows, cols;

    // Prompt user for matrix dimensions
    while (true) {
        cout << "Enter the number of rows: ";
        cin >> rows;
        cout << "Enter the number of columns: ";
        cin >> cols;

        if (validateMatrixDimensions(rows, cols, systemSolve)) {
            break;
        }
    }

    Matrix mat(rows, cols);

    if (argc > 1) {
        // Validate program argument size
        int totalElements = argc - 1; // Remaining arguments are matrix data
        if (totalElements != rows * cols) {
            throw runtime_error("The number of elements in program arguments does not match the specified matrix dimensions.");
        }

        // Fill matrix from program arguments
        mat.inputMatrix(argv, 1); // Start reading data from argv[1]
        return mat;
    } else {
        // Input matrix manually
        mat.inputMatrix();
        return mat;
    }
}

int main(int argc, char* argv[]) {
    map<char, Matrix> matrices;
    int choice;
    bool systemSolve = true; // Assume the matrix is for solving linear equations

    try {
        cout << "Enter dimensions of your matrix (rows x cols):\n";
        Matrix mat = getMatrixFromArgsOrInput(argc, argv, systemSolve);
        cout << "Matrix successfully created:\n";
        mat.display();
        matrices['A'] = mat;
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << "\n";
        return 1;
    }

    do {
        printMainMenu();
        cin >> choice;
        clearInputBuffer();

        switch (choice) {
            case 1: { // Create new matrix
                char label = getMatrixLabel();
                bool newSystemSolve = false; // Allow user to specify non-system matrices
                cout << "Is this matrix for solving a system of equations? (y/n): ";
                char resp;
                cin >> resp;
                if (tolower(resp) == 'y') {
                    newSystemSolve = true;
                }
                Matrix newMat = getMatrixFromArgsOrInput(0, nullptr, newSystemSolve);
                matrices[label] = newMat;
                cout << "Matrix " << label << " created successfully.\n";
                break;
            }
            case 2: { // Perform operations
                if (matrices.empty()) {
                    cout << "No matrices available. Please create a matrix first.\n";
                    continue;
                }

                listMatrices(matrices);
                char label = getMatrixLabel();

                if (matrices.find(label) == matrices.end()) {
                    cout << "Matrix " << label << " does not exist.\n";
                    continue;
                }

                int operation;
                do {
                    printOperationMenu();
                    cin >> operation;

                    if (operation == 8) break;
                    if (operation < 1 || operation > 8) {
                        cout << "Invalid option. Please try again.\n";
                        continue;
                    }

                    processMatrixOperation(matrices[label], operation);
                } while (true);
                break;
            }
            case 3: { // List matrices
                listMatrices(matrices);
                break;
            }
            case 4: { // Delete matrix
                if (matrices.empty()) {
                    cout << "No matrices to delete.\n";
                    continue;
                }

                listMatrices(matrices);
                char label = getMatrixLabel();

                if (matrices.find(label) == matrices.end()) {
                    cout << "Matrix " << label << " does not exist.\n";
                    continue;
                }

                matrices.erase(label);
                cout << "Matrix " << label << " deleted successfully.\n";
                break;
            }
            case 5: { // Exit
                cout << "Exiting program.\n";
                break;
            }
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
