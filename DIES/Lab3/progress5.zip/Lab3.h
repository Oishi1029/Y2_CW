// Lab3.h
#ifndef LAB3_H
#define LAB3_H

#include <vector>
#include <string>
#include <sstream>  // for ostringstream and stringstream
#include <fstream>  // for ofstream and ifstream
#include <iostream>
#include <map>
#include <cctype>
#include <limits>
#include <iomanip>
#include <cmath>
#include <stdexcept>
using namespace std;

class Matrix {
private:
    vector<vector<double>> data;
    int rows;
    int cols;

public:
    Matrix() : rows(0), cols(0) {} // Default constructor
    Matrix(int n, int m);

    Matrix transpose();
    static Matrix identity(int n);
    static Matrix zero(int n, int m);
    Matrix operator+(const Matrix& other);
    Matrix operator-(const Matrix& other);
    Matrix operator*(const Matrix& other); // Matrix multiplication
    Matrix operator*(double scalar);      // Scalar multiplication
    string solutionType();

    void inputMatrix();
    void inputMatrix(char* argv[], int startIdx);
    void inputValue(int i, int j, double value);
    vector<double> solveLinearSystem();
    Matrix inverse();
    void print();
    void set(int m, int n, double x);
    double get(int m, int n);
    void save(string filename);
    void load(string filename);
    bool isEmpty() const { return rows == 0 || cols == 0; }
    int getRows() const { return rows; }
    int getCols() const { return cols; }
    void resize(int n, int m);
    void display();

private:
    double determinant();
    void swapRows(int i, int j);
    Matrix augmentIdentity();
    bool isSquare();
    bool isValidIndex(int m, int n) const;
};

void clearInputBuffer();

void printMainMenu();

void printOperationMenu();

bool validateDimensions(int rows, int cols, int operation);

void listMatrices(const map<char, Matrix>& matrices);
char getMatrixLabel();

void processMatrixOperation(Matrix& mat, int operation);
#endif