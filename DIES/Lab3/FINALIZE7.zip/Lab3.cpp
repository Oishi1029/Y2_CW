// Lab3.cpp
#include "Lab3.h"


Matrix::Matrix(int n, int m) : rows(n), cols(m) {
    data.resize(n, vector<double>(m, 0.0));
}


bool validateMatrixDimensions(int rows, int cols, bool systemSolve) {
    if (cols == rows + 1) {
        cout << "The matrix have dimensions n x (n+1), applicable for solving system of linear equation.\n";
        return true;
    }

    if (cols == rows) {
        cout << "The matrix is a square matrix, not applicable for solving system of linear equation. \n";
        return true;
    }
    return false;
}

bool askToUpdateMatrix(Matrix& currentMatrix, const Matrix& resultMatrix) {
    char updateChoice;
    cout << "Do you want to update the current matrix with the new result? (y/n): ";
    cin >> updateChoice;
    updateChoice = tolower(updateChoice); // Convert to lowercase for consistency

    if (updateChoice == 'y') {
        currentMatrix = resultMatrix; // Update the current matrix
        cout << "Current matrix updated successfully.\n";
        return true;
    }

    cout << "Current matrix is not updated with the result.\n";
    return false;
}

void Matrix::inputMatrix() {
    cout << "Enter the matrix elements row by row:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << "Enter element [" << i << "][" << j << "]: ";
            cin >> data[i][j];
        }
    }
}

void Matrix::inputMatrix(char* argv[], int startIdx) {
    int idx = startIdx;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            data[i][j] = stod(argv[idx++]);
        }
    }
}

void Matrix::display() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << fixed << setprecision(2) << setw(8) << data[i][j] << " ";
        }
        cout << endl;
    }
}
/*
Matrix Matrix::rowEchelon() {
    int n = rows;
    int m = cols;
    vector<vector<double>> augmented = data;

    // Perform Gaussian elimination
    for (int i = 0; i < n; i++) {
        // Find pivot
        int maxRow = i;
        for (int k = i + 1; k < n; k++) {
            if (abs(augmented[k][i]) > abs(augmented[maxRow][i])) {
                maxRow = k;
            }
        }

        // Swap maximum row with current row
        if (maxRow != i) {
            swap(augmented[i], augmented[maxRow]);
        }

        // Make all rows below this one 0 in current column
        for (int k = i + 1; k < n; k++) {
            double factor = augmented[k][i] / augmented[i][i];
            for (int j = i; j < m; j++) {
                augmented[k][j] -= factor * augmented[i][j];
            }
        }
    }

    // Create and return the REF matrix
    Matrix ref(n, m);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            ref.data[i][j] = augmented[i][j];
        }
    }

    return ref;
}
*/
Matrix Matrix::rowEchelon() {
    int n = rows;
    int m = cols;
    vector<vector<double>> augmented = data;

    // Perform Gaussian elimination
    for (int i = 0; i < n; i++) {
        // Find pivot
        int maxRow = i;
        for (int k = i + 1; k < n; k++) {
            if (abs(augmented[k][i]) > abs(augmented[maxRow][i])) {
                maxRow = k;
            }
        }

        // Swap maximum row with current row
        if (maxRow != i) {
            swap(augmented[i], augmented[maxRow]);
        }

        // Check if the pivot is zero
        if (abs(augmented[i][i]) < 1e-10) {
            continue; // Skip this row if it's effectively zero
        }

        // Scale the pivot row to make the pivot equal to 1
        double pivot = augmented[i][i];
        for (int j = i; j < m; j++) {
            augmented[i][j] /= pivot;
        }

        // Make all rows below this one 0 in current column
        for (int k = i + 1; k < n; k++) {
            double factor = augmented[k][i];
            for (int j = i; j < m; j++) {
                augmented[k][j] -= factor * augmented[i][j];
            }
        }
    }

    // Create and return the REF matrix
    Matrix ref(n, m);
    ref.data = augmented; // Directly assign the modified data
    return ref;
}
Matrix Matrix::reducedRowEchelon() {
    Matrix ref = rowEchelon(); // Get REF
    int n = ref.rows;
    int m = ref.cols;
    vector<vector<double>> augmented = ref.data;

    // Convert REF to RREF
    for (int i = n - 1; i >= 0; i--) {
        double pivot = augmented[i][i];
        for (int j = 0; j < m; j++) {
            augmented[i][j] /= pivot; // Normalize the pivot row
        }
        for (int k = i - 1; k >= 0; k--) {
            double factor = augmented[k][i];
            for (int j = 0; j < m; j++) {
                augmented[k][j] -= factor * augmented[i][j];
            }
        }
    }

    // Create and return the RREF matrix
    Matrix rref(n, m);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            rref.data[i][j] = augmented[i][j];
        }
    }

    return rref;
}
vector<double> Matrix::solveLinearSystem() {
    if (cols != rows + 1) {
        throw runtime_error("Matrix must have n rows and n+1 columns for system solving");
    }

    // Get the reduced row echelon form
    Matrix rref = reducedRowEchelon();

    // Determine the rank of the coefficient matrix and the augmented matrix
    int rank = 0;
    int augmentedRank = 0;

    // Check for consistency and determine ranks
    for (int i = 0; i < rows; i++) {
        bool isZeroRow = true;
        bool isAugmentedZeroRow = true;

        for (int j = 0; j < cols; j++) {
            if (abs(rref.data[i][j]) > 1e-10) {
                isZeroRow = false;
            }
            if (j < cols - 1 && abs(rref.data[i][j]) > 1e-10) { // Check for non-zero in coefficient part
                isAugmentedZeroRow = false;
            }
        }

        if (!isZeroRow) {
            rank++;
        }
        if (!isAugmentedZeroRow && abs(rref.data[i][cols - 1]) > 1e-10) { // Check for non-zero in the last column
            augmentedRank++;
        }
    }

    // Determine the type of solution
    if (rank < augmentedRank) {
        cout << "No Solution\n";
        return {}; // No solution
    } else if (rank < rows) {
        cout << "Infinite Solutions\n";
        return {}; // Infinite solutions
    }

    // If we reach here, we have a unique solution
    vector<double> solution(rows);
    for (int i = rows - 1; i >= 0; i--) {
        solution[i] = rref.data[i][cols - 1]; // The last column is the solution
        for (int j = i + 1; j < cols - 1; j++) { // Exclude the last column
            solution[i] -= rref.data[i][j] * solution[j];
        }
    }

    return solution;
}
/*
vector<double> Matrix::solveLinearSystem() {
    if (cols != rows + 1) {
        throw runtime_error("Matrix must have n rows and n+1 columns for system solving");
    }

    vector<vector<double>> augmented = data;
    int n = rows;

    // Gaussian elimination
    for (int i = 0; i < n; i++) {
        // Find pivot
        int maxRow = i;
        for (int k = i + 1; k < n; k++) {
            if (abs(augmented[k][i]) > abs(augmented[maxRow][i])) {
                maxRow = k;
            }
        }

        // Swap maximum row with current row
        if (maxRow != i) {
            swap(augmented[i], augmented[maxRow]);
        }

        // Make all rows below this one 0 in current column
        for (int k = i + 1; k < n; k++) {
            double factor = augmented[k][i] / augmented[i][i];
            for (int j = i; j <= n; j++) {
                augmented[k][j] -= factor * augmented[i][j];
            }
        }
    }

    // Back substitution
    vector<double> solution(n);
    for (int i = n - 1; i >= 0; i--) {
        solution[i] = augmented[i][n];
        for (int j = i + 1; j < n; j++) {
            solution[i] -= augmented[i][j] * solution[j];
        }
        solution[i] /= augmented[i][i];
    }

    return solution;
}
*/
bool Matrix::isSquare() {
    return rows == cols;
}

Matrix Matrix::augmentIdentity() {
    if (!isSquare()) {
        throw runtime_error("Matrix must be square for inversion");
    }

    Matrix augmented(rows, 2 * cols);

    // Copy original matrix
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            augmented.data[i][j] = data[i][j];
        }
    }

    // Add identity matrix
    for (int i = 0; i < rows; i++) {
        augmented.data[i][i + cols] = 1.0;
    }

    return augmented;
}

Matrix Matrix::inverse() {
    if (!isSquare()) {
        throw runtime_error("Matrix must be square for inversion");
    }

    Matrix augmented = augmentIdentity();

    // Gaussian elimination
    for (int i = 0; i < rows; i++) {
        // Find pivot
        int maxRow = i;
        for (int k = i + 1; k < rows; k++) {
            if (abs(augmented.data[k][i]) > abs(augmented.data[maxRow][i])) {
                maxRow = k;
            }
        }

        if (abs(augmented.data[maxRow][i]) < 1e-10) {
            throw runtime_error("Matrix is singular, cannot find inverse");
        }

        // Swap maximum row with current row
        if (maxRow != i) {
            swap(augmented.data[i], augmented.data[maxRow]);
        }

        // Scale current row
        double scale = augmented.data[i][i];
        for (int j = i; j < 2 * cols; j++) {
            augmented.data[i][j] /= scale;
        }

        // Eliminate column
        for (int k = 0; k < rows; k++) {
            if (k != i) {
                double factor = augmented.data[k][i];
                for (int j = i; j < 2 * cols; j++) {
                    augmented.data[k][j] -= factor * augmented.data[i][j];
                }
            }
        }
    }

    // Extract inverse matrix
    Matrix inverse(rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            inverse.data[i][j] = augmented.data[i][j + cols];
        }
    }

    return inverse;
}

// Add this method to Lab3.cpp
void Matrix::inputValue(int i, int j, double value) {
    if (i >= 0 && i < rows && j >= 0 && j < cols) {
        data[i][j] = value;
    }
}

void Matrix::print() {
    int maxWidth = 0;

    // Find the maximum width needed
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            ostringstream ss;
            ss << fixed << setprecision(6) << data[i][j];
            maxWidth = max(maxWidth, static_cast<int>(ss.str().length()));
        }
    }

    // Print the matrix with aligned columns
    cout << "\n";
    for (int i = 0; i < rows; i++) {
        cout << "|";
        for (int j = 0; j < cols; j++) {
            cout << setw(maxWidth + 2) << fixed << setprecision(6) << data[i][j];
        }
        cout << " |\n";
    }
    cout << "\n";
}

bool Matrix::isValidIndex(int m, int n) const {
    return m >= 0 && m < rows && n >= 0 && n < cols;
}

void Matrix::set(int m, int n, double x) {
    if (!isValidIndex(m, n)) {
        throw out_of_range("Matrix indices out of range");
    }
    data[m][n] = x;
}

double Matrix::get(int m, int n) {
    if (!isValidIndex(m, n)) {
        throw out_of_range("Matrix indices out of range");
    }
    return data[m][n];
}

void Matrix::save(string filename) {
    // Check if filename has an extension
    size_t dotPos = filename.find_last_of('.');
    string extension = (dotPos != string::npos) ? filename.substr(dotPos) : "";

    // If no extension, ask the user for one
    if (extension.empty()) {
        char choice;
        cout << "No file extension provided. Choose an extension:\n";
        cout << "1. .mat\n";
        cout << "2. .txt\n";
        cout << "Enter your choice (1/2): ";
        cin >> choice;

        if (choice == '1') {
            filename += ".mat";
        } else {
            filename += ".txt";
        }
    }

    cout << "Matrix saved successfully to " << filename << endl;

    ofstream outFile(filename);
    if (!outFile) {
        throw runtime_error("Unable to open file for writing: " + filename);
    }

    // Write in MATLAB/Octave ASCII format
    outFile << scientific << setprecision(16);

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            outFile << data[i][j];
            if (j < cols - 1) outFile << " "; // Space between elements
        }
        outFile << "\n"; // New line after each row
    }

    outFile.close();
    if (!outFile) {
        throw runtime_error("Error occurred while writing to file: " + filename);
    }
}
void Matrix::load(string filename) {
    // Check if filename has an extension
    size_t dotPos = filename.find_last_of('.');
    string extension = (dotPos != string::npos) ? filename.substr(dotPos) : "";

    // If no extension, ask the user for one
    if (extension.empty()) {
        char choice;
        cout << "No file extension provided. Choose an extension:\n";
        cout << "1. .mat\n";
        cout << "2. .txt\n";
        cout << "Enter your choice (1/2): ";
        cin >> choice;

        if (choice == '1') {
            filename += ".mat";
        } else if (choice == '2') {
            filename += ".txt";
        } else {
            throw runtime_error("Invalid choice for file extension.");
        }
    }

    ifstream inFile(filename);
    if (!inFile) {
        throw runtime_error("Unable to open file: " + filename);
    }

    vector<vector<double>> tempData;
    string line;
    int numCols = -1;

    while (getline(inFile, line)) {
        // Skip empty lines
        if (line.empty()) continue;

        vector<double> row;
        stringstream ss(line);
        double value;

        while (ss >> value) {
            row.push_back(value);
        }

        // Verify consistency of number of columns
        if (numCols == -1) {
            numCols = row.size();
        } else if (numCols != static_cast<int>(row.size())) {
            throw runtime_error("Inconsistent number of columns in file: " + filename);
        }

        tempData.push_back(row);
    }

    if (tempData.empty()) {
        throw runtime_error("No data found in file: " + filename);
    }

    // Update matrix dimensions and data
    rows = tempData.size();
    cols = tempData[0].size();
    data = tempData;
}


Matrix Matrix::identity(int n) {
    Matrix identity(n, n);
    for (int i = 0; i < n; i++) {
        identity.data[i][i] = 1.0;
    }
    return identity;
}

Matrix Matrix::zero(int n, int m) {
    return Matrix(n, m);
}

Matrix Matrix::transpose() const {
    Matrix result(cols, rows);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result.data[j][i] = data[i][j];
        }
    }
    return result;
}




Matrix Matrix::operator+(const Matrix& other) const {
    if (rows != other.rows || cols != other.cols) {
        throw runtime_error("Dimension mismatch for addition.");
    }
    Matrix result(rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result.data[i][j] = data[i][j] + other.data[i][j];
        }
    }
    return result;
}

Matrix Matrix::operator-(const Matrix& other) const {
    if (rows != other.rows || cols != other.cols) {
        throw runtime_error("Dimension mismatch for subtraction.");
    }
    Matrix result(rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result.data[i][j] = data[i][j] - other.data[i][j];
        }
    }
    return result;
}

Matrix Matrix::operator*(const Matrix& other) const {
    if (cols != other.rows) {
        throw runtime_error("Dimension mismatch for multiplication.");
    }
    Matrix result(rows, other.cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < other.cols; j++) {
            for (int k = 0; k < cols; k++) {
                result.data[i][j] += data[i][k] * other.data[k][j];
            }
        }
    }
    return result;
}

Matrix Matrix::operator*(double scalar) const {
    Matrix result(rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result.data[i][j] = data[i][j] * scalar;
        }
    }
    return result;
}

string Matrix::solutionType() {
    if (cols != rows + 1) {
        throw runtime_error("Matrix must have dimensions n x (n+1) for solution analysis.");
    }

    vector<vector<double>> augmented = data; // Copy for row reduction
    int n = rows;

    // Row reduction to echelon form
    for (int i = 0; i < n; i++) {
        // Find pivot
        int maxRow = i;
        for (int k = i + 1; k < n; k++) {
            if (abs(augmented[k][i]) > abs(augmented[maxRow][i])) {
                maxRow = k;
            }
        }

        // Swap rows if necessary
        if (maxRow != i) {
            swap(augmented[i], augmented[maxRow]);
        }

        // If pivot is zero, the system might be degenerate
        if (abs(augmented[i][i]) < 1e-10) {
            continue;
        }

        // Eliminate below
        for (int k = i + 1; k < n; k++) {
            double factor = augmented[k][i] / augmented[i][i];
            for (int j = i; j <= n; j++) {
                augmented[k][j] -= factor * augmented[i][j];
            }
        }
    }

    // Analyze the reduced matrix
    int rank = 0;
    for (int i = 0; i < n; i++) {
        bool nonZeroRow = false;
        for (int j = 0; j < cols; j++) {
            if (abs(augmented[i][j]) > 1e-10) {
                nonZeroRow = true;
                break;
            }
        }
        if (nonZeroRow) rank++;
    }

    if (rank < n) {
        // Check for inconsistency (e.g., 0 = 1)
        for (int i = rank; i < n; i++) {
            if (abs(augmented[i][n]) > 1e-10) {
                return "No Solution";
            }
        }
        return "Infinite Solutions";
    }

    return "Unique Solution";
}

double Matrix::determinant() const {
    if (rows != cols) {
        throw runtime_error("Determinant can only be calculated for square matrices.");
    }

    vector<vector<double>> temp = data; // Copy the matrix to perform operations
    double det = 1.0;

    for (int i = 0; i < rows; i++) {
        // Find pivot
        int pivotRow = i;
        for (int j = i + 1; j < rows; j++) {
            if (abs(temp[j][i]) > abs(temp[pivotRow][i])) {
                pivotRow = j;
            }
        }

        if (abs(temp[pivotRow][i]) < 1e-10) {
            return 0.0; // Singular matrix
        }

        // Swap rows if necessary
        if (pivotRow != i) {
            swap(temp[i], temp[pivotRow]);
            det *= -1; // Row swap changes the sign of the determinant
        }

        // Scale determinant by pivot
        det *= temp[i][i];

        // Eliminate below
        for (int j = i + 1; j < rows; j++) {
            double factor = temp[j][i] / temp[i][i];
            for (int k = i; k < cols; k++) {
                temp[j][k] -= factor * temp[i][k];
            }
        }
    }

    return det;
}


void clearInputBuffer() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void printMainMenu() {
    cout << "\nMain Menu:\n";
    cout << "1. Create new matrix\n";
    cout << "2. Select matrix to perform operations\n";
    cout << "3. List all matrices\n";
    cout << "4. Delete matrix\n";
    cout << "5. Exit\n";
    cout << "Enter choice (1-5): ";
}
void printOperationMenu() {
    const int width = 50; // Set a uniform width for each menu item

    //cout << "\nEssential Matrix Operations Menu:                Mathematical Operations Menu:\n";

    cout << left << setw(width) << "Essential Matrix Operations Menu"
         << left << setw(width) << "Mathematical Operations Menu:" << endl;
    cout << left << setw(width) << "1. Find row echelon form (REF)"
         << left << setw(width) << "11. Transpose" << endl;
    cout << left << setw(width) << "2. Find reduced row echelon form (RREF)"
         << left << setw(width) << "12. Identity Matrix" << endl;
    cout << left << setw(width) << "3. Solve system of linear equations"
         << left << setw(width) << "13. Zero Matrix" << endl;
    cout << left << setw(width) << "4. Find inverse matrix (Gaussian method)"
         << left << setw(width) << "14. Add Matrices" << endl;
    cout << left << setw(width) << "5. Print matrix"
         << left << setw(width) << "15. Subtract Matrices" << endl;
    cout << left << setw(width) << "6. Set specific element"
         << left << setw(width) << "16. Left Multiply Matrices" << endl;
    cout << left << setw(width) << "7. Get specific element"
         << left << setw(width) << "17. Right Multiply Matrices" << endl;
    cout << left << setw(width) << "8. Save matrix to file"
         << left << setw(width) << "18. Scalar Multiply" << endl;
    cout << left << setw(width) << "9. Load matrix from file"
         << left << setw(width) << "19. Inverse (Normal method)" << endl;
    cout << left << setw(width) << "10. Return to main menu"
         << left << setw(width) << "20. Determinant" << endl;
    cout << "\nEnter choice (1-20): ";
}

bool validateDimensions(int rows, int cols, int operation) {
    if (operation == 1 && cols != rows + 1) {
        cout << "For system solving, columns must be rows + 1\n";
        return false;
    }
    if (operation == 2 && cols != rows) {
        cout << "For inverse, matrix must be square\n";
        return false;
    }
    return true;
}

void listMatrices(const map<char, Matrix>& matrices) {
    cout << "\nExisting matrices label (e.g. A, B, C, D):\n";
    if (matrices.empty()) {
        cout << "No matrices created yet.\n";
        return;
    }
    for (const auto& pair : matrices) {
        cout << "Matrix " << pair.first << " ("
             << pair.second.getRows() << "x"
             << pair.second.getCols() << ")\n";
    }
}

char getMatrixLabel() {
    char label;
    do {
        cout << "Enter matrix label (A-Z): ";
        cin >> label;
        label = toupper(label);
        clearInputBuffer();

        if (label < 'A' || label > 'Z') {
            cout << "Invalid label. Please use letters A-Z.\n";
            continue;
        }
        break;
    } while (true);
    return label;
}




void processMatrixOperation(Matrix& mat, int operation, map<char, Matrix>& matrices) {
    try {
        Matrix result;
        switch (operation) {

            case 1:
                if (!validateDimensions(mat.getRows(), mat.getCols(), 1)) return;
                result = mat.rowEchelon();
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            case 2:
                if (!validateDimensions(mat.getRows(), mat.getCols(), 1)) return;
                result = mat.reducedRowEchelon();
                result.print();
                askToUpdateMatrix(mat, result);
                break;


            case 3: { // Solve system
                if (!validateDimensions(mat.getRows(), mat.getCols(), 1)) return;
                cout << "\nSolution Type: " << mat.solutionType() << endl;

                if (mat.solutionType() == "Unique Solution") {
                    vector<double> solution = mat.solveLinearSystem();
                    cout << "\nSolution:\n";
                    for (size_t i = 0; i < solution.size(); i++) {
                        cout << "x" << i + 1 << " = " << solution[i] << endl;
                    }
                }
                break;
            }
            case 4: { // Inverse
                if (!validateDimensions(mat.getRows(), mat.getCols(), 2)) return;
                result = mat.inverse();
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 5: { // Print
                mat.print();
                return;
            }
            case 6: { // Set element
                int m, n;
                double value;
                cout << "Enter row index: ";
                cin >> m;
                cout << "Enter column index: ";
                cin >> n;
                cout << "Enter value: ";
                cin >> value;
                mat.set(m, n, value);
                cout << "Element updated successfully.\n";
                return;
            }
            case 7: { // Get element
                int m, n;
                cout << "Enter row index: ";
                cin >> m;
                cout << "Enter column index: ";
                cin >> n;
                double value = mat.get(m, n);
                cout << "Value at (" << m << "," << n << ") = " << value << endl;
                return;
            }
            case 8: { // Save
                string filename;
                cout << "Enter filename to save: ";
                clearInputBuffer();
                getline(cin, filename);
                mat.save(filename);
                //cout << "Matrix saved successfully to " << filename << endl;
                return;
            }
            case 9: { // Load
                string filename;
                cout << "Enter filename to load: ";
                clearInputBuffer();
                getline(cin, filename);
                mat.load(filename);
                cout << "Matrix loaded successfully from " << filename << endl;
                mat.print();
                return;
            }
            case 11: { // Transpose
                result = mat.transpose();
                result.print(); // Print the transposed matrix
                askToUpdateMatrix(mat, result);
                break;
            }
            case 12: { // Identity
                int size;
                cout << "Enter size of the identity matrix: ";
                cin >> size;
                result = Matrix::identity(size);
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 13: { // Zero
                int rows, cols;
                cout << "Enter number of rows: ";
                cin >> rows;
                cout << "Enter number of columns: ";
                cin >> cols;
                result = Matrix::zero(rows, cols);
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 14: { // Add
                char label;
                listMatrices(matrices);
                cout << "Enter the label of the matrix to add: ";
                cin >> label;
                label = toupper(label);
                if (matrices.find(label) == matrices.end()) {
                    throw runtime_error("Matrix not found.");
                }
                result = mat + matrices[label];
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 15: { // Subtract
                char label;
                listMatrices(matrices);
                cout << "Enter the label of the matrix to subtract: ";
                cin >> label;
                label = toupper(label);
                if (matrices.find(label) == matrices.end()) {
                    throw runtime_error("Matrix not found.");
                }
                result = mat - matrices[label];
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 16: { // Left Multiply
                char label;
                listMatrices(matrices);
                cout << "Enter the label of the matrix for left multiplication: ";
                cin >> label;
                label = toupper(label);
                if (matrices.find(label) == matrices.end()) {
                    throw runtime_error("Matrix not found.");
                }
                result = matrices[label] * mat;
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 17: { // Right Multiply
                char label;
                listMatrices(matrices);
                cout << "Enter the label of the matrix for right multiplication: ";
                cin >> label;
                label = toupper(label);
                if (matrices.find(label) == matrices.end()) {
                    throw runtime_error("Matrix not found.");
                }
                result = mat * matrices[label];
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 18: { // Scalar Multiply
                double scalar;
                cout << "Enter the scalar value: ";
                cin >> scalar;
                result = mat * scalar;
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 19: { // Inverse
                result = mat.inverse();
                result.print();
                askToUpdateMatrix(mat, result);
                break;
            }
            case 20: { // Determinant
                if (mat.getRows() != mat.getCols()) {
                    cout << "Determinant can only be calculated for square matrices.\n";
                    break;
                }
                double det = mat.determinant();
                cout << "Determinant: " << det << endl;
                break;
            }

        }

    } catch (const exception& e) {
        cout << "Error: " << e.what() << endl;
    }
}
